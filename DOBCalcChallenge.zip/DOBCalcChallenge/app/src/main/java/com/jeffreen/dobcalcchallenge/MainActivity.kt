package com.jeffreen.dobcalcchallenge

import android.app.DatePickerDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private var dateResultTxt: TextView? = null
    private var dateBtn: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dateResultTxt = findViewById(R.id.results)
        dateBtn = findViewById(R.id.dateSelectBtn)
        dateBtn?.setOnClickListener {
            selectDate()
        }
    }

    private fun selectDate() {
        // Calendar Instance.
        val calendarDate: Calendar = Calendar.getInstance()

        // Current Date Variables.
        val year: Int = calendarDate.get(Calendar.YEAR)
        val month: Int = calendarDate.get(Calendar.MONTH)
        val day: Int = calendarDate.get(Calendar.DAY_OF_MONTH)

        // Showcase the Calendar on screen.
        val datePickerFunction = DatePickerDialog(this@MainActivity, { view, selectedYear, selectedMonth, selectedDay ->
            
            val selectedDateTxt: String = "${selectedMonth + 1}/${selectedDay}/${selectedYear}"
            val sdf = SimpleDateFormat("MM/dd/yyyy", Locale.US)
            val theDate = sdf.parse(selectedDateTxt)
            
            dateBtn?.text = selectedDateTxt
            
            theDate?.let {
                val dateInMinutes = theDate.time / 86400000
                val currentDate = sdf.parse(sdf.format(System.currentTimeMillis()))
                currentDate?.let{
                    val currentDateInMinutes = currentDate.time / 86400000
                    val difference = currentDateInMinutes - dateInMinutes

                    if(difference > 1) {
                        dateResultTxt?.text = difference.toString() + " Days"
                    } else {
                        dateResultTxt?.text = difference.toString() + " Day"
                    }
                }
            }

        },
            year,
            month,
            day
        )

        datePickerFunction.datePicker.maxDate = System.currentTimeMillis() - 86400000
        datePickerFunction.show()
    }
}